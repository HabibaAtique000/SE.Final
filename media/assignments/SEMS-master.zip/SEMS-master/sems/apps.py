from django.apps import AppConfig


class SemsConfig(AppConfig):
    name = 'sems'
