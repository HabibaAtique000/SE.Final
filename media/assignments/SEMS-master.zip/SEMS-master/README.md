# SEMS
Sistemi Elektronik për Menaxhimin e Studentëve
#
### Login

Username: `admin`

Password: `admin123`

![Image](https://i.imgur.com/urz8xKb.png)
